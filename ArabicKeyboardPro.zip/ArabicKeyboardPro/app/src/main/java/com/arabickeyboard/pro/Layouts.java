package com.arabickeyboard.pro;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

public final class Layouts {
    public static final int MODE_LETTERS = 0;
    public static final int MODE_SYM1 = 1;
    public static final int MODE_SYM2 = 2;
    public static final int MODE_EMOJI = 3;

    private static final String AR_DIGITS = "٠١٢٣٤٥٦٧٨٩";
    private static final String EN_DIGITS = "0123456789";

    private static final int[][] EMOJI = {
            range(0x1F600, 32),
            {0x1F44D, 0x1F44E, 0x1F44A, 0x270A, 0x270C, 0x1F44C, 0x1F44B, 0x1F44F,
                    0x1F64F, 0x1F4AA, 0x1F446, 0x1F447, 0x1F448, 0x1F449, 0x261D, 0x1F450,
                    0x1F64C, 0x1F91D, 0x1F91E, 0x1F918, 0x1F919, 0x1F91F, 0x1F91A, 0x270B,
                    0x1F590, 0x1F64B, 0x1F485, 0x1F440, 0x1F441, 0x1F442, 0x1F443, 0x1F444},
            {0x2764, 0x1F9E1, 0x1F49B, 0x1F49A, 0x1F499, 0x1F49C, 0x1F5A4, 0x1F90D,
                    0x1F90E, 0x1F494, 0x2763, 0x1F495, 0x1F49E, 0x1F493, 0x1F497, 0x1F496,
                    0x1F498, 0x1F49D, 0x1F48B, 0x1F4AF, 0x1F4A5, 0x1F4AB, 0x2728, 0x1F525,
                    0x1F31F, 0x2B50, 0x1F389, 0x1F38A, 0x1F381, 0x1F3C6, 0x1F451, 0x1F48E},
            range(0x1F400, 32),
            range(0x1F345, 32),
            range(0x1F4B0, 32),
            range(0x1F680, 32)
    };
    private static final int[] EMOJI_TABS = {0x1F600, 0x1F44D, 0x2764, 0x1F431, 0x1F354, 0x1F4B0, 0x1F697};

    public static class Row {
        public final List<Key> keys = new ArrayList<>();
        public final float h;

        Row(float h) { this.h = h; }

        Row add(Key k) { keys.add(k); return this; }
    }

    private Layouts() {}

    private static int[] range(int from, int count) {
        int[] a = new int[count];
        for (int i = 0; i < count; i++) a[i] = from + i;
        return a;
    }

    private static String cp(int cp) {
        String s = new String(Character.toChars(cp));
        return cp < 0x10000 ? s + "\uFE0F" : s;
    }

    public static List<Row> build(int mode, boolean arabic, int shift, boolean numberRow,
                                  boolean arabicDigits, int emojiCat) {
        List<Row> rows = new ArrayList<>();
        switch (mode) {
            case MODE_SYM1:
                rows.add(digits(arabicDigits, 1f));
                symbols1(rows);
                rows.add(bottom(arabic, false));
                break;
            case MODE_SYM2:
                rows.add(digits(arabicDigits, 1f));
                symbols2(rows);
                rows.add(bottom(arabic, false));
                break;
            case MODE_EMOJI:
                emoji(rows, emojiCat);
                break;
            default:
                if (numberRow) rows.add(digits(arabicDigits, 0.78f));
                if (arabic) arabicRows(rows, shift != 0);
                else englishRows(rows, shift != 0);
                rows.add(bottom(arabic, true));
        }
        return rows;
    }

    private static Row digits(boolean arabicDigits, float h) {
        Row r = new Row(h);
        String main = arabicDigits ? AR_DIGITS : EN_DIGITS;
        String alt = arabicDigits ? EN_DIGITS : AR_DIGITS;
        for (int i = 1; i <= 10; i++) {
            int d = i % 10;
            r.add(Key.ch(String.valueOf(main.charAt(d)), String.valueOf(alt.charAt(d))));
        }
        return r;
    }

    private static Row bottom(boolean arabic, boolean lettersMode) {
        Row r = new Row(1f);
        if (lettersMode) r.add(Key.fn(Key.SYM1, "123", 1.3f));
        else r.add(Key.fn(Key.LETTERS, arabic ? "أبج" : "ABC", 1.3f));
        r.add(Key.fn(Key.EMOJI, "\uD83D\uDE0A", 1f));
        r.add(Key.fn(Key.LANG, arabic ? "EN" : "ع", 1f));
        r.add(arabic ? Key.ch("،", ",") : Key.ch(","));
        r.add(new Key(Key.SPACE, arabic ? "العربية" : "English", " ", 3.4f));
        r.add(arabic
                ? Key.ch(".", "،", "؟", "!", ":", "؛", "…")
                : Key.ch(".", "?", "!", ":", ";", "…", "-"));
        r.add(Key.fn(Key.ENTER, "", 1.4f));
        return r;
    }

    // ---------------- Arabic ----------------

    private static Key arKey(char c) {
        String s = String.valueOf(c);
        switch (c) {
            case 'ا': return Key.ch(s, "أ", "إ", "آ", "ٱ");
            case 'و': return Key.ch(s, "ؤ");
            case 'ي': return Key.ch(s, "ى", "ئ");
            case 'ه': return Key.ch(s, "ة");
            case 'ة': return Key.ch(s, "ه");
            case 'ك': return Key.ch(s, "گ");
            case 'ب': return Key.ch(s, "پ");
            case 'ج': return Key.ch(s, "چ");
            case 'ف': return Key.ch(s, "ڤ");
            case 'ق': return Key.ch(s, "ڨ");
            case 'ز': return Key.ch(s, "ژ");
            case 'ء': return Key.ch(s, "أ", "إ", "ؤ", "ئ");
            case 'ل': return Key.ch(s, "لا", "لأ", "لإ", "لآ");
            default: return Key.ch(s);
        }
    }

    private static Row arLetters(String s) {
        Row r = new Row(1f);
        for (char c : s.toCharArray()) r.add(arKey(c));
        return r;
    }

    private static void arabicRows(List<Row> rows, boolean tashkeel) {
        if (!tashkeel) {
            rows.add(arLetters("ضصثقفغعهخحجد"));
            rows.add(arLetters("شسيبلاتنمكطذ"));
            Row r3 = new Row(1f);
            r3.add(Key.fn(Key.SHIFT, "", 1.4f));
            for (char c : "ئءؤرىةوزظ".toCharArray()) r3.add(arKey(c));
            r3.add(Key.fn(Key.DELETE, "", 1.4f));
            rows.add(r3);
        } else {
            Row r1 = new Row(1f);
            int[] marks = {0x64E, 0x64B, 0x64F, 0x64C, 0x650, 0x64D, 0x651, 0x652, 0x670, 0x653, 0x654};
            for (int m : marks) r1.add(Key.mark(m));
            r1.add(Key.ch("ـ"));
            rows.add(r1);
            Row r2 = new Row(1f);
            for (char c : "أإآپچڤگژڨٱ؟٪".toCharArray()) r2.add(Key.ch(String.valueOf(c)));
            rows.add(r2);
            Row r3 = new Row(1f);
            r3.add(Key.fn(Key.SHIFT, "", 1.4f));
            for (char c : "!()«»-،:\"".toCharArray()) r3.add(Key.ch(String.valueOf(c)));
            r3.add(Key.fn(Key.DELETE, "", 1.4f));
            rows.add(r3);
        }
    }

    // ---------------- English ----------------

    private static String[] enPopups(char c) {
        switch (c) {
            case 'a': return new String[]{"à", "á", "â", "ä", "æ", "ã", "å", "ā"};
            case 'e': return new String[]{"è", "é", "ê", "ë", "ē", "ė", "ę"};
            case 'i': return new String[]{"ì", "í", "î", "ï", "ī", "į"};
            case 'o': return new String[]{"ò", "ó", "ô", "ö", "œ", "ø", "ō", "õ"};
            case 'u': return new String[]{"ù", "ú", "û", "ü", "ū"};
            case 'c': return new String[]{"ç", "ć", "č"};
            case 'n': return new String[]{"ñ", "ń"};
            case 's': return new String[]{"ß", "ś", "š"};
            case 'y': return new String[]{"ý", "ÿ"};
            case 'z': return new String[]{"ž", "ź", "ż"};
            case 'l': return new String[]{"ł"};
            default: return null;
        }
    }

    private static Key enKey(char c, boolean upper) {
        String s = String.valueOf(c);
        if (upper) s = s.toUpperCase(Locale.ROOT);
        String[] p = enPopups(c);
        if (p == null) return Key.ch(s);
        String[] q = new String[p.length];
        for (int i = 0; i < p.length; i++) {
            q[i] = (upper && !p[i].equals("ß")) ? p[i].toUpperCase(Locale.ROOT) : p[i];
        }
        return Key.ch(s, q);
    }

    private static void englishRows(List<Row> rows, boolean upper) {
        Row r1 = new Row(1f);
        for (char c : "qwertyuiop".toCharArray()) r1.add(enKey(c, upper));
        rows.add(r1);
        Row r2 = new Row(1f);
        r2.add(Key.fn(Key.SPACER, "", 0.5f));
        for (char c : "asdfghjkl".toCharArray()) r2.add(enKey(c, upper));
        r2.add(Key.fn(Key.SPACER, "", 0.5f));
        rows.add(r2);
        Row r3 = new Row(1f);
        r3.add(Key.fn(Key.SHIFT, "", 1.5f));
        for (char c : "zxcvbnm".toCharArray()) r3.add(enKey(c, upper));
        r3.add(Key.fn(Key.DELETE, "", 1.5f));
        rows.add(r3);
    }

    // ---------------- Symbols ----------------

    private static Key sym(String s) {
        switch (s) {
            case "$": return Key.ch(s, "€", "£", "¥", "¢");
            case "-": return Key.ch(s, "–", "—", "•");
            case "\"": return Key.ch(s, "«", "»", "“", "”");
            case "'": return Key.ch(s, "‘", "’");
            case "(": return Key.ch(s, "[", "{", "<");
            case ")": return Key.ch(s, "]", "}", ">");
            case "/": return Key.ch(s, "\\", "|");
            case ";": return Key.ch(s, "؛");
            case "?": return Key.ch(s, "؟");
            case "%": return Key.ch(s, "‰", "٪");
            case "=": return Key.ch(s, "≠", "≈");
            default: return Key.ch(s);
        }
    }

    private static Row symRow(String chars) {
        Row r = new Row(1f);
        for (int i = 0; i < chars.length(); i++) r.add(sym(String.valueOf(chars.charAt(i))));
        return r;
    }

    private static void symbols1(List<Row> rows) {
        rows.add(symRow("@#$_&-+()/"));
        Row r = new Row(1f);
        r.add(Key.fn(Key.SYM2, "=\\<", 1.3f));
        for (char c : "*\"':;!?".toCharArray()) r.add(sym(String.valueOf(c)));
        r.add(Key.fn(Key.DELETE, "", 1.3f));
        rows.add(r);
    }

    private static void symbols2(List<Row> rows) {
        rows.add(symRow("~`|•√π÷×¶∆"));
        Row r = new Row(1f);
        r.add(Key.fn(Key.SYM2, "1/2", 1.3f));
        for (char c : "£€¥^°={}%".toCharArray()) r.add(sym(String.valueOf(c)));
        r.add(Key.fn(Key.DELETE, "", 1.3f));
        rows.add(r);
    }

    // ---------------- Emoji ----------------

    private static void emoji(List<Row> rows, int cat) {
        int[] data = EMOJI[Math.max(0, Math.min(cat, EMOJI.length - 1))];
        for (int i = 0; i < 4; i++) {
            Row r = new Row(1f);
            for (int j = 0; j < 8; j++) {
                int idx = i * 8 + j;
                Key k = Key.ch(idx < data.length ? cp(data[idx]) : "");
                k.flat = true;
                r.add(k);
            }
            rows.add(r);
        }
        Row b = new Row(1f);
        b.add(Key.fn(Key.LETTERS, "أبج", 1.4f));
        for (int i = 0; i < EMOJI_TABS.length; i++) {
            Key t = Key.fn(Key.CAT, cp(EMOJI_TABS[i]), 1f);
            t.arg = i;
            b.add(t);
        }
        b.add(Key.fn(Key.DELETE, "", 1.4f));
        rows.add(b);
    }
}
