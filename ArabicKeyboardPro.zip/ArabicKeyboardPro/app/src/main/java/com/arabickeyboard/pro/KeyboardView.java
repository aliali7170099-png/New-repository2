package com.arabickeyboard.pro;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.RectF;
import android.media.AudioManager;
import android.os.Build;
import android.os.Handler;
import android.os.Looper;
import android.os.VibrationEffect;
import android.os.Vibrator;
import android.util.SparseArray;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.widget.PopupWindow;

import java.util.ArrayList;
import java.util.List;

public class KeyboardView extends View {

    public interface Listener {
        void onKey(Key key);
        void onText(String text);
        void onLongPressKey(Key key);
    }

    private static class Ptr {
        Key key;
        boolean consumed;
        boolean altShown;
        PopupWindow altWin;
        PopupStrip altStrip;
        float altLeft;
        Runnable longPress;
        Runnable repeat;
    }

    private final SparseArray<Ptr> ptrs = new SparseArray<>();
    private final Handler handler = new Handler(Looper.getMainLooper());
    private final Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Path path = new Path();
    private final RectF tmp = new RectF();
    private final float density;
    private final int[] loc = new int[2];

    private List<Layouts.Row> rows = new ArrayList<>();
    private boolean rtl = true;
    private boolean dirty = true;
    private Theme theme = Theme.get(0);
    private Listener listener;
    private int shiftState;
    private int selectedCat;
    private String enterLabel;
    private String spaceLabel = "";
    private int keyHeightPx;
    private boolean vibrateOn = true, soundOn = false, previewOn = true;

    private PopupWindow previewWin;
    private PopupStrip previewStrip;
    private Vibrator vibrator;
    private AudioManager audio;

    public KeyboardView(Context c) {
        super(c);
        density = c.getResources().getDisplayMetrics().density;
        keyHeightPx = Math.round(50 * density);
        vibrator = (Vibrator) c.getSystemService(Context.VIBRATOR_SERVICE);
        audio = (AudioManager) c.getSystemService(Context.AUDIO_SERVICE);
        setLayerType(LAYER_TYPE_NONE, null);
    }

    private float dp(float v) { return v * density; }

    public void setListener(Listener l) { listener = l; }

    public void setTheme(Theme t) {
        theme = t;
        setBackgroundColor(t.bg);
        invalidate();
    }

    public void setOptions(boolean vibrate, boolean sound, boolean preview, int keyHeightDp) {
        vibrateOn = vibrate;
        soundOn = sound;
        previewOn = preview;
        int px = Math.round(keyHeightDp * density);
        if (px != keyHeightPx) {
            keyHeightPx = px;
            dirty = true;
            requestLayout();
        }
    }

    public void setEnterLabel(String label) {
        enterLabel = label;
        invalidate();
    }

    public void setLayout(List<Layouts.Row> newRows, boolean rtl, int shiftState, int selectedCat,
                          String spaceLabel) {
        cancelAll();
        this.rows = newRows;
        this.rtl = rtl;
        this.shiftState = shiftState;
        this.selectedCat = selectedCat;
        this.spaceLabel = spaceLabel;
        dirty = true;
        requestLayout();
        invalidate();
    }

    public void reset() {
        cancelAll();
        invalidate();
    }

    // ---------------- measure / layout ----------------

    @Override
    protected void onMeasure(int widthSpec, int heightSpec) {
        int w = MeasureSpec.getSize(widthSpec);
        float h = dp(6) * 2;
        for (Layouts.Row r : rows) h += r.h * keyHeightPx;
        setMeasuredDimension(w, Math.round(h));
    }

    @Override
    protected void onSizeChanged(int w, int h, int ow, int oh) {
        dirty = true;
    }

    private void computeRects() {
        int w = getWidth();
        if (w <= 0) return;
        float hpad = dp(3);
        float y = dp(6);
        for (Layouts.Row r : rows) {
            float sum = 0;
            for (Key k : r.keys) sum += k.weight;
            float unit = (w - 2 * hpad) / sum;
            float rowH = r.h * keyHeightPx;
            float off = 0;
            for (Key k : r.keys) {
                float kw = unit * k.weight;
                float left = rtl ? (w - hpad - off - kw) : (hpad + off);
                k.rect.set(left, y, left + kw, y + rowH);
                off += kw;
            }
            y += rowH;
        }
        dirty = false;
    }

    private Key findKey(float x, float y) {
        if (dirty) computeRects();
        Key best = null;
        float bestD = Float.MAX_VALUE;
        for (Layouts.Row r : rows) {
            for (Key k : r.keys) {
                if (k.code == Key.SPACER) continue;
                float dx = x < k.rect.left ? k.rect.left - x : (x > k.rect.right ? x - k.rect.right : 0);
                float dy = y < k.rect.top ? k.rect.top - y : (y > k.rect.bottom ? y - k.rect.bottom : 0);
                float d = dx * dx + dy * dy;
                if (d < bestD) {
                    bestD = d;
                    best = k;
                }
            }
        }
        return best;
    }

    // ---------------- drawing ----------------

    @Override
    protected void onDraw(Canvas c) {
        if (dirty) computeRects();
        float gx = dp(2.5f), gy = dp(3f), rad = dp(7f);
        for (Layouts.Row r : rows) {
            for (Key k : r.keys) {
                if (k.code == Key.SPACER) continue;
                tmp.set(k.rect.left + gx, k.rect.top + gy, k.rect.right - gx, k.rect.bottom - gy);
                int fill;
                int textColor = theme.text;
                if (k.code == Key.ENTER) {
                    fill = theme.accent;
                    textColor = theme.accentText;
                    if (k.pressed) fill = blend(fill, 0xFF000000, 0.25f);
                } else if ((k.code == Key.SHIFT && shiftState == 2)
                        || (k.code == Key.CAT && k.arg == selectedCat)) {
                    fill = theme.accent;
                    textColor = theme.accentText;
                } else if (k.isFunc()) {
                    fill = k.pressed ? theme.funcPressed : theme.func;
                    textColor = theme.textFunc;
                } else {
                    fill = k.pressed ? theme.keyPressed : theme.key;
                }

                if (k.flat) {
                    if (k.pressed) {
                        paint.setStyle(Paint.Style.FILL);
                        paint.setColor(theme.keyPressed);
                        c.drawRoundRect(tmp, rad, rad, paint);
                    }
                } else {
                    paint.setStyle(Paint.Style.FILL);
                    paint.setColor(theme.shadow);
                    float so = dp(1.2f);
                    c.drawRoundRect(tmp.left, tmp.top + so, tmp.right, tmp.bottom + so, rad, rad, paint);
                    paint.setColor(fill);
                    c.drawRoundRect(tmp, rad, rad, paint);
                }
                drawKeyContent(c, k, tmp, textColor);
            }
        }
    }

    private void drawKeyContent(Canvas c, Key k, RectF r, int color) {
        float base = keyHeightPx * 0.40f;
        float icon = Math.min(r.height(), keyHeightPx) * 0.42f;
        switch (k.code) {
            case Key.SHIFT:
                drawShift(c, r.centerX(), r.centerY(), icon, shiftState != 0, color);
                break;
            case Key.DELETE:
                drawDelete(c, r.centerX(), r.centerY(), icon, color);
                break;
            case Key.ENTER:
                if (enterLabel != null) drawText(c, enterLabel, r, base * 0.72f, color);
                else drawEnter(c, r.centerX(), r.centerY(), icon, color);
                break;
            case Key.SPACE:
                drawText(c, spaceLabel, r, base * 0.62f, theme.hint);
                break;
            case Key.SYM1:
            case Key.SYM2:
            case Key.LETTERS:
            case Key.LANG:
                drawText(c, k.label, r, base * 0.70f, color);
                break;
            case Key.CAT:
                drawText(c, k.label, r, base * 0.85f, color);
                break;
            default:
                if (k.flat) drawText(c, k.label, r, base * 1.15f, color);
                else drawText(c, k.label, r, k.weight > 1f ? base * 0.75f : base, color);
        }
    }

    private void drawText(Canvas c, String s, RectF r, float size, int color) {
        if (s == null || s.isEmpty()) return;
        paint.setStyle(Paint.Style.FILL);
        paint.setTextSize(size);
        paint.setColor(color);
        paint.setTextAlign(Paint.Align.CENTER);
        Paint.FontMetrics fm = paint.getFontMetrics();
        c.drawText(s, r.centerX(), r.centerY() - (fm.ascent + fm.descent) / 2f, paint);
    }

    private void strokeSetup(int color) {
        paint.setStyle(Paint.Style.STROKE);
        paint.setStrokeWidth(dp(1.9f));
        paint.setStrokeCap(Paint.Cap.ROUND);
        paint.setStrokeJoin(Paint.Join.ROUND);
        paint.setColor(color);
    }

    private void resetPaint() {
        paint.setStrokeWidth(0);
        paint.setStyle(Paint.Style.FILL);
    }

    private void drawShift(Canvas c, float cx, float cy, float s, boolean filled, int color) {
        path.reset();
        path.moveTo(cx, cy - s / 2);
        path.lineTo(cx + s / 2, cy);
        path.lineTo(cx + s / 4, cy);
        path.lineTo(cx + s / 4, cy + s / 2);
        path.lineTo(cx - s / 4, cy + s / 2);
        path.lineTo(cx - s / 4, cy);
        path.lineTo(cx - s / 2, cy);
        path.close();
        strokeSetup(color);
        paint.setStyle(filled ? Paint.Style.FILL_AND_STROKE : Paint.Style.STROKE);
        c.drawPath(path, paint);
        resetPaint();
    }

    private void drawDelete(Canvas c, float cx, float cy, float s, int color) {
        c.save();
        if (rtl) c.scale(-1f, 1f, cx, cy);
        float h = s * 0.42f;
        path.reset();
        path.moveTo(cx - s / 2, cy);
        path.lineTo(cx - s / 6, cy - h);
        path.lineTo(cx + s / 2, cy - h);
        path.lineTo(cx + s / 2, cy + h);
        path.lineTo(cx - s / 6, cy + h);
        path.close();
        strokeSetup(color);
        c.drawPath(path, paint);
        float q = s * 0.16f, mx = cx + s * 0.14f;
        c.drawLine(mx - q, cy - q, mx + q, cy + q, paint);
        c.drawLine(mx - q, cy + q, mx + q, cy - q, paint);
        c.restore();
        resetPaint();
    }

    private void drawEnter(Canvas c, float cx, float cy, float s, int color) {
        c.save();
        if (rtl) c.scale(-1f, 1f, cx, cy);
        path.reset();
        path.moveTo(cx + s / 2, cy - s / 2);
        path.lineTo(cx + s / 2, cy + s / 8);
        path.lineTo(cx - s / 2, cy + s / 8);
        strokeSetup(color);
        c.drawPath(path, paint);
        path.reset();
        path.moveTo(cx - s / 6, cy - s / 5);
        path.lineTo(cx - s / 2, cy + s / 8);
        path.lineTo(cx - s / 6, cy + s * 0.45f);
        c.drawPath(path, paint);
        c.restore();
        resetPaint();
    }

    private static int blend(int a, int b, float t) {
        int r = Math.round(((a >> 16) & 0xFF) * (1 - t) + ((b >> 16) & 0xFF) * t);
        int g = Math.round(((a >> 8) & 0xFF) * (1 - t) + ((b >> 8) & 0xFF) * t);
        int bl = Math.round((a & 0xFF) * (1 - t) + (b & 0xFF) * t);
        return 0xFF000000 | (r << 16) | (g << 8) | bl;
    }

    // ---------------- touch ----------------

    @Override
    public boolean onTouchEvent(MotionEvent e) {
        switch (e.getActionMasked()) {
            case MotionEvent.ACTION_DOWN:
            case MotionEvent.ACTION_POINTER_DOWN: {
                int i = e.getActionIndex();
                onDown(e.getPointerId(i), e.getX(i), e.getY(i));
                break;
            }
            case MotionEvent.ACTION_MOVE:
                for (int i = 0; i < e.getPointerCount(); i++) {
                    onMove(e.getPointerId(i), e.getX(i), e.getY(i));
                }
                break;
            case MotionEvent.ACTION_UP:
            case MotionEvent.ACTION_POINTER_UP: {
                int i = e.getActionIndex();
                onUp(e.getPointerId(i));
                break;
            }
            case MotionEvent.ACTION_CANCEL:
                cancelAll();
                break;
            default:
                break;
        }
        return true;
    }

    private void onDown(int id, float x, float y) {
        Key k = findKey(x, y);
        if (k == null) return;
        Ptr p = new Ptr();
        p.key = k;
        ptrs.put(id, p);
        press(id, p);
    }

    private void press(final int id, final Ptr p) {
        final Key k = p.key;
        k.pressed = true;
        feedback(k);
        invalidate();
        if (k.code == Key.DELETE) {
            p.consumed = true;
            if (listener != null) listener.onKey(k);
            p.repeat = new Runnable() {
                @Override
                public void run() {
                    if (ptrs.get(id) != p) return;
                    if (listener != null) listener.onKey(p.key);
                    handler.postDelayed(this, 55);
                }
            };
            handler.postDelayed(p.repeat, 400);
            return;
        }
        if (k.code == Key.CHAR || k.code == Key.SPACE) showPreview(k);
        if (k.popups != null || k.code == Key.LANG) {
            p.longPress = new Runnable() {
                @Override
                public void run() {
                    if (ptrs.get(id) != p || p.key != k) return;
                    if (k.code == Key.LANG) {
                        p.consumed = true;
                        if (listener != null) listener.onLongPressKey(k);
                    } else {
                        showAlt(p);
                    }
                }
            };
            handler.postDelayed(p.longPress, 350);
        }
    }

    private void onMove(int id, float x, float y) {
        Ptr p = ptrs.get(id);
        if (p == null) return;
        if (p.altShown) {
            updateAlt(p, x);
            return;
        }
        if (p.consumed) return;
        Key nk = findKey(x, y);
        if (nk != null && nk != p.key) {
            cancelTimers(p);
            p.key.pressed = false;
            hidePreview();
            p.key = nk;
            press(id, p);
        }
    }

    private void onUp(int id) {
        Ptr p = ptrs.get(id);
        if (p == null) return;
        ptrs.remove(id);
        cancelTimers(p);
        p.key.pressed = false;
        hidePreview();
        if (p.altShown) {
            String sel = null;
            if (p.altStrip != null && p.altStrip.sel >= 0) sel = p.altStrip.items[p.altStrip.sel];
            dismissAlt(p);
            if (sel != null && listener != null) listener.onText(sel);
        } else if (!p.consumed && listener != null) {
            listener.onKey(p.key);
        }
        invalidate();
    }

    private void cancelTimers(Ptr p) {
        if (p.longPress != null) handler.removeCallbacks(p.longPress);
        if (p.repeat != null) handler.removeCallbacks(p.repeat);
        p.longPress = null;
        p.repeat = null;
    }

    private void cancelAll() {
        for (int i = 0; i < ptrs.size(); i++) {
            Ptr p = ptrs.valueAt(i);
            cancelTimers(p);
            p.key.pressed = false;
            dismissAlt(p);
        }
        ptrs.clear();
        hidePreview();
        invalidate();
    }

    @Override
    protected void onDetachedFromWindow() {
        cancelAll();
        super.onDetachedFromWindow();
    }

    private void feedback(Key k) {
        if (vibrateOn && vibrator != null) {
            try {
                if (Build.VERSION.SDK_INT >= 26) {
                    vibrator.vibrate(VibrationEffect.createOneShot(14, VibrationEffect.DEFAULT_AMPLITUDE));
                } else {
                    vibrator.vibrate(14);
                }
            } catch (Exception ignored) {
            }
        }
        if (soundOn && audio != null) {
            int fx = AudioManager.FX_KEYPRESS_STANDARD;
            if (k.code == Key.SPACE) fx = AudioManager.FX_KEYPRESS_SPACEBAR;
            else if (k.code == Key.DELETE) fx = AudioManager.FX_KEYPRESS_DELETE;
            else if (k.code == Key.ENTER) fx = AudioManager.FX_KEYPRESS_RETURN;
            audio.playSoundEffect(fx, -1f);
        }
    }

    // ---------------- popups ----------------

    private void showPreview(Key k) {
        if (!previewOn || k.code != Key.CHAR || k.label == null || k.label.isEmpty()) return;
        try {
            if (previewStrip == null) previewStrip = new PopupStrip(getContext());
            int w = Math.round(Math.max(k.rect.width() + dp(14), dp(50)));
            int h = Math.round(dp(58));
            previewStrip.setPreview(k.label, theme, dp(26));
            getLocationOnScreen(loc);
            int x = Math.round(loc[0] + k.rect.centerX() - w / 2f);
            int maxX = getResources().getDisplayMetrics().widthPixels - w;
            x = Math.max(0, Math.min(x, maxX));
            int y = Math.round(loc[1] + k.rect.top - h - dp(4));
            if (previewWin == null) {
                previewWin = new PopupWindow(previewStrip, w, h);
                previewWin.setTouchable(false);
                previewWin.setClippingEnabled(false);
            }
            if (previewWin.isShowing()) previewWin.update(x, y, w, h);
            else previewWin.showAtLocation(this, Gravity.NO_GRAVITY, x, y);
        } catch (Exception ignored) {
        }
    }

    private void hidePreview() {
        if (previewWin != null && previewWin.isShowing()) {
            try {
                previewWin.dismiss();
            } catch (Exception ignored) {
            }
        }
    }

    private void showAlt(Ptr p) {
        Key k = p.key;
        hidePreview();
        try {
            String[] items = k.popups;
            int n = items.length;
            float itemW = dp(42), itemH = dp(52), pad = dp(4);
            float totalW = n * itemW + 2 * pad;
            getLocationOnScreen(loc);
            float keyCx = loc[0] + k.rect.centerX();
            boolean reverse = k.rect.centerX() > getWidth() / 2f;
            float left = reverse ? keyCx + itemW / 2f + pad - totalW : keyCx - itemW / 2f - pad;
            int screenW = getResources().getDisplayMetrics().widthPixels;
            left = Math.max(0, Math.min(left, screenW - totalW));
            float top = loc[1] + k.rect.top - itemH - dp(10);

            PopupStrip strip = new PopupStrip(getContext());
            strip.setAlt(items, reverse, theme, itemW, itemH, pad, dp(22));
            PopupWindow win = new PopupWindow(strip, Math.round(totalW), Math.round(itemH + pad));
            win.setTouchable(false);
            win.setClippingEnabled(false);
            win.showAtLocation(this, Gravity.NO_GRAVITY, Math.round(left), Math.round(top));
            p.altWin = win;
            p.altStrip = strip;
            p.altLeft = left;
            p.altShown = true;
            p.consumed = true;
            strip.sel = 0;
            strip.invalidate();
        } catch (Exception ignored) {
        }
    }

    private void updateAlt(Ptr p, float x) {
        if (p.altStrip == null) return;
        getLocationOnScreen(loc);
        float screenX = loc[0] + x;
        PopupStrip s = p.altStrip;
        int n = s.items.length;
        int slot = (int) Math.floor((screenX - p.altLeft - s.pad) / s.itemW);
        slot = Math.max(0, Math.min(n - 1, slot));
        int sel = s.reverse ? n - 1 - slot : slot;
        if (sel != s.sel) {
            s.sel = sel;
            s.invalidate();
        }
    }

    private void dismissAlt(Ptr p) {
        if (p.altWin != null) {
            try {
                p.altWin.dismiss();
            } catch (Exception ignored) {
            }
        }
        p.altWin = null;
        p.altStrip = null;
        p.altShown = false;
    }

    // ---------------- popup content view ----------------

    static class PopupStrip extends View {
        String[] items = new String[0];
        int sel = -1;
        boolean reverse;
        boolean alt;
        float itemW, itemH, pad, textSize;
        Theme theme = Theme.get(0);
        private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final RectF r = new RectF();
        private final float density;

        PopupStrip(Context c) {
            super(c);
            density = c.getResources().getDisplayMetrics().density;
        }

        void setPreview(String s, Theme t, float textSize) {
            items = new String[]{s};
            alt = false;
            theme = t;
            this.textSize = textSize;
            invalidate();
        }

        void setAlt(String[] it, boolean reverse, Theme t, float itemW, float itemH, float pad, float textSize) {
            items = it;
            alt = true;
            this.reverse = reverse;
            theme = t;
            this.itemW = itemW;
            this.itemH = itemH;
            this.pad = pad;
            this.textSize = textSize;
            invalidate();
        }

        @Override
        protected void onDraw(Canvas c) {
            float rad = 10 * density;
            p.setStyle(Paint.Style.FILL);
            p.setColor(theme.shadow);
            r.set(0, 2 * density, getWidth(), getHeight());
            c.drawRoundRect(r, rad, rad, p);
            p.setColor(theme.popupBg);
            r.set(0, 0, getWidth(), getHeight() - 2 * density);
            c.drawRoundRect(r, rad, rad, p);
            p.setTextAlign(Paint.Align.CENTER);
            p.setTextSize(textSize);
            Paint.FontMetrics fm = p.getFontMetrics();
            if (!alt) {
                p.setColor(theme.popupText);
                c.drawText(items[0], getWidth() / 2f,
                        (getHeight() - 2 * density) / 2f - (fm.ascent + fm.descent) / 2f, p);
                return;
            }
            int n = items.length;
            for (int slot = 0; slot < n; slot++) {
                int idx = reverse ? n - 1 - slot : slot;
                float l = pad + slot * itemW;
                if (idx == sel) {
                    p.setColor(theme.accent);
                    r.set(l, pad, l + itemW, getHeight() - pad - 2 * density);
                    c.drawRoundRect(r, rad * 0.7f, rad * 0.7f, p);
                    p.setColor(theme.accentText);
                } else {
                    p.setColor(theme.popupText);
                }
                c.drawText(items[idx], l + itemW / 2f,
                        (getHeight() - 2 * density) / 2f - (fm.ascent + fm.descent) / 2f, p);
            }
        }
    }
}
