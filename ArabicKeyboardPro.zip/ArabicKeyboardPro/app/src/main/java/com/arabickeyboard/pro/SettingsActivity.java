package com.arabickeyboard.pro;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.provider.Settings;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.view.inputmethod.InputMethodInfo;
import android.view.inputmethod.InputMethodManager;
import android.widget.Button;
import android.widget.CompoundButton;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.ScrollView;
import android.widget.SeekBar;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;

public class SettingsActivity extends Activity {

    private Prefs prefs;
    private TextView status1, status2, heightLabel;
    private float d;

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        prefs = new Prefs(this);
        d = getResources().getDisplayMetrics().density;
        getWindow().getDecorView().setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
        getWindow().setStatusBarColor(0xFF0F1A2E);

        ScrollView sv = new ScrollView(this);
        sv.setBackgroundColor(0xFFF3F5F9);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(16), dp(16), dp(16), dp(32));
        sv.addView(root);

        TextView title = text("الكيبورد العربي برو", 24, true, 0xFF0F1A2E);
        root.addView(title);
        root.addView(text("لوحة مفاتيح عربية احترافية مع تشكيل وإيموجي واقتراحات ذكية", 14, false, 0xFF5A6478));
        root.addView(space(12));

        // --- steps
        LinearLayout c1 = card(root);
        c1.addView(text("١. تفعيل لوحة المفاتيح", 16, true, 0xFF1B1F27));
        status1 = text("", 14, false, 0xFF5A6478);
        c1.addView(status1);
        c1.addView(button("فتح إعدادات لوحات المفاتيح", new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(Settings.ACTION_INPUT_METHOD_SETTINGS));
            }
        }));

        LinearLayout c2 = card(root);
        c2.addView(text("٢. اختيار لوحة المفاتيح", 16, true, 0xFF1B1F27));
        status2 = text("", 14, false, 0xFF5A6478);
        c2.addView(status2);
        c2.addView(button("اختيار الكيبورد الآن", new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                InputMethodManager imm = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
                if (imm != null) imm.showInputMethodPicker();
            }
        }));

        // --- theme
        LinearLayout c3 = card(root);
        c3.addView(text("المظهر", 16, true, 0xFF1B1F27));
        RadioGroup rg = new RadioGroup(this);
        for (int i = 0; i < Theme.NAMES.length; i++) {
            RadioButton rb = new RadioButton(this);
            rb.setId(1000 + i);
            rb.setText(Theme.NAMES[i]);
            rb.setTextSize(15);
            rg.addView(rb);
        }
        rg.check(1000 + prefs.theme());
        rg.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(RadioGroup g, int id) {
                prefs.putInt(Prefs.THEME, id - 1000);
            }
        });
        c3.addView(rg);

        // --- key height
        LinearLayout c4 = card(root);
        heightLabel = text("", 16, true, 0xFF1B1F27);
        c4.addView(heightLabel);
        SeekBar sb = new SeekBar(this);
        sb.setMax(26);
        sb.setProgress(prefs.keyHeight() - 38);
        updateHeightLabel(prefs.keyHeight());
        sb.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar s, int p, boolean user) {
                prefs.putInt(Prefs.KEY_HEIGHT, p + 38);
                updateHeightLabel(p + 38);
            }

            @Override
            public void onStartTrackingTouch(SeekBar s) {
            }

            @Override
            public void onStopTrackingTouch(SeekBar s) {
            }
        });
        c4.addView(sb);

        // --- toggles
        LinearLayout c5 = card(root);
        c5.addView(text("الخيارات", 16, true, 0xFF1B1F27));
        c5.addView(toggle(Prefs.NUMBER_ROW, "صف الأرقام أعلى الحروف", true));
        c5.addView(toggle(Prefs.ARABIC_DIGITS, "أرقام عربية (١٢٣) بدل (123)", false));
        c5.addView(toggle(Prefs.SUGGEST, "اقتراحات الكلمات", true));
        c5.addView(toggle(Prefs.DOUBLE_SPACE, "نقطة بالضغط مرتين على المسافة", true));
        c5.addView(toggle(Prefs.PREVIEW, "معاينة الحرف عند الضغط", true));
        c5.addView(toggle(Prefs.VIBRATE, "اهتزاز عند الكتابة", true));
        c5.addView(toggle(Prefs.SOUND, "صوت عند الكتابة", false));
        c5.addView(button("مسح الكلمات المتعلَّمة", new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                new SuggestionEngine(SettingsActivity.this).clearLearned();
                Toast.makeText(SettingsActivity.this, "تم المسح", Toast.LENGTH_SHORT).show();
            }
        }));

        // --- test field
        LinearLayout c6 = card(root);
        c6.addView(text("جرّب الكيبورد", 16, true, 0xFF1B1F27));
        EditText et = new EditText(this);
        et.setHint("اكتب هنا...");
        et.setMinLines(3);
        et.setGravity(Gravity.TOP | Gravity.START);
        c6.addView(et);

        root.addView(text("نصائح: اضغط مطولاً على أي حرف لرؤية الأشكال الأخرى (أ إ آ، ة، ئ ...). "
                + "زر Shift يفتح طبقة التشكيل. اضغط مطولاً على زر اللغة لتبديل لوحات المفاتيح.",
                13, false, 0xFF5A6478));
        setContentView(sv);
    }

    @Override
    protected void onResume() {
        super.onResume();
        refreshStatus();
    }

    private void refreshStatus() {
        boolean enabled = false;
        InputMethodManager imm = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
        if (imm != null) {
            for (InputMethodInfo i : imm.getEnabledInputMethodList()) {
                if (i.getPackageName().equals(getPackageName())) enabled = true;
            }
        }
        String cur = Settings.Secure.getString(getContentResolver(), Settings.Secure.DEFAULT_INPUT_METHOD);
        boolean selected = cur != null && cur.startsWith(getPackageName() + "/");
        status1.setText(enabled ? "✓ مفعّلة" : "✗ غير مفعّلة");
        status1.setTextColor(enabled ? 0xFF1B8A3E : 0xFFC62828);
        status2.setText(selected ? "✓ هي لوحة المفاتيح الحالية" : "✗ ليست لوحة المفاتيح الحالية");
        status2.setTextColor(selected ? 0xFF1B8A3E : 0xFFC62828);
    }

    private void updateHeightLabel(int v) {
        heightLabel.setText("ارتفاع المفاتيح: " + v);
    }

    // ---------------- UI helpers ----------------

    private int dp(float v) {
        return Math.round(v * d);
    }

    private TextView text(String s, float size, boolean bold, int color) {
        TextView t = new TextView(this);
        t.setText(s);
        t.setTextSize(size);
        t.setTextColor(color);
        if (bold) t.setTypeface(Typeface.DEFAULT_BOLD);
        t.setPadding(0, dp(2), 0, dp(4));
        return t;
    }

    private View space(int h) {
        View v = new View(this);
        v.setLayoutParams(new LinearLayout.LayoutParams(1, dp(h)));
        return v;
    }

    private LinearLayout card(LinearLayout parent) {
        LinearLayout c = new LinearLayout(this);
        c.setOrientation(LinearLayout.VERTICAL);
        c.setPadding(dp(16), dp(12), dp(16), dp(12));
        GradientDrawable g = new GradientDrawable();
        g.setColor(Color.WHITE);
        g.setCornerRadius(dp(14));
        c.setBackground(g);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        lp.topMargin = dp(10);
        parent.addView(c, lp);
        return c;
    }

    private Button button(String label, View.OnClickListener l) {
        Button bt = new Button(this);
        bt.setText(label);
        bt.setOnClickListener(l);
        return bt;
    }

    private Switch toggle(final String key, String label, boolean def) {
        Switch s = new Switch(this);
        s.setText(label);
        s.setTextSize(15);
        s.setChecked(prefs.getBool(key, def));
        s.setPadding(0, dp(8), 0, dp(8));
        s.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton v, boolean on) {
                prefs.putBool(key, on);
            }
        });
        return s;
    }
}
