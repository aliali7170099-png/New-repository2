package com.arabickeyboard.pro;

import android.content.Context;
import android.content.SharedPreferences;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

public class SuggestionEngine {
    private static final int MAX_LEARNED = 400;

    private final List<String> arWords = new ArrayList<>();
    private final List<String> arNorm = new ArrayList<>();
    private final List<String> enWords = new ArrayList<>();
    private final Map<String, Integer> learned = new LinkedHashMap<>();
    private final SharedPreferences sp;

    public SuggestionEngine(Context c) {
        sp = c.getSharedPreferences("kb_learned", Context.MODE_PRIVATE);
        load(c, R.raw.words_ar, arWords);
        for (String w : arWords) arNorm.add(normalize(w));
        load(c, R.raw.words_en, enWords);
        reloadLearned();
    }

    private static void load(Context c, int res, List<String> out) {
        try {
            InputStream in = c.getResources().openRawResource(res);
            BufferedReader br = new BufferedReader(new InputStreamReader(in, "UTF-8"));
            String line;
            while ((line = br.readLine()) != null) {
                line = line.trim();
                if (!line.isEmpty()) out.add(line);
            }
            br.close();
        } catch (Exception ignored) {
        }
    }

    public void reloadLearned() {
        learned.clear();
        String data = sp.getString("learned", "");
        if (data == null || data.isEmpty()) return;
        for (String line : data.split("\n")) {
            int t = line.lastIndexOf('\t');
            if (t <= 0) continue;
            try {
                learned.put(line.substring(0, t), Integer.parseInt(line.substring(t + 1)));
            } catch (NumberFormatException ignored) {
            }
        }
    }

    private void save() {
        StringBuilder sb = new StringBuilder();
        for (Map.Entry<String, Integer> e : learned.entrySet()) {
            sb.append(e.getKey()).append('\t').append(e.getValue()).append('\n');
        }
        sp.edit().putString("learned", sb.toString()).apply();
    }

    public void clearLearned() {
        learned.clear();
        sp.edit().remove("learned").apply();
    }

    public void learn(String word) {
        if (word == null) return;
        word = word.trim();
        if (word.length() < 2 || word.length() > 24) return;
        Integer n = learned.get(word);
        learned.put(word, n == null ? 1 : n + 1);
        if (learned.size() > MAX_LEARNED) {
            String minKey = null;
            int min = Integer.MAX_VALUE;
            for (Map.Entry<String, Integer> e : learned.entrySet()) {
                if (e.getValue() < min && !e.getKey().equals(word)) {
                    min = e.getValue();
                    minKey = e.getKey();
                }
            }
            if (minKey != null) learned.remove(minKey);
        }
        save();
    }

    public List<String> suggest(String prefix, int max) {
        List<String> out = new ArrayList<>();
        if (prefix == null || prefix.isEmpty()) return out;
        String np = normalize(prefix);
        if (np.isEmpty()) return out;
        boolean arabic = isArabic(prefix.charAt(0));

        // 1) learned words, most used first
        List<Map.Entry<String, Integer>> hits = new ArrayList<>();
        for (Map.Entry<String, Integer> e : learned.entrySet()) {
            String w = e.getKey();
            if (isArabic(w.charAt(0)) == arabic && normalize(w).startsWith(np) && !w.equals(prefix)) {
                hits.add(e);
            }
        }
        Collections.sort(hits, new Comparator<Map.Entry<String, Integer>>() {
            @Override
            public int compare(Map.Entry<String, Integer> a, Map.Entry<String, Integer> b) {
                return b.getValue() - a.getValue();
            }
        });
        for (Map.Entry<String, Integer> e : hits) {
            if (out.size() >= max) return out;
            out.add(matchCase(e.getKey(), prefix, arabic));
        }

        // 2) built-in dictionary
        if (arabic) {
            for (int i = 0; i < arWords.size() && out.size() < max; i++) {
                String w = arWords.get(i);
                if (arNorm.get(i).startsWith(np) && !w.equals(prefix) && !out.contains(w)) out.add(w);
            }
        } else {
            for (int i = 0; i < enWords.size() && out.size() < max; i++) {
                String w = enWords.get(i);
                if (w.startsWith(np) && !w.equals(np)) {
                    String m = matchCase(w, prefix, false);
                    if (!out.contains(m)) out.add(m);
                }
            }
        }
        return out;
    }

    private static String matchCase(String w, String prefix, boolean arabic) {
        if (arabic || prefix.isEmpty()) return w;
        if (prefix.length() > 1 && prefix.equals(prefix.toUpperCase(Locale.ROOT))) {
            return w.toUpperCase(Locale.ROOT);
        }
        if (Character.isUpperCase(prefix.charAt(0))) {
            return Character.toUpperCase(w.charAt(0)) + w.substring(1);
        }
        return w;
    }

    public static boolean isArabic(char c) {
        return c >= 0x0600 && c <= 0x06FF;
    }

    public static String normalize(String s) {
        StringBuilder sb = new StringBuilder(s.length());
        for (int i = 0; i < s.length(); i++) {
            char c = s.charAt(i);
            if ((c >= 0x064B && c <= 0x065F) || c == 0x0670 || c == 0x0640) continue;
            switch (c) {
                case 'أ':
                case 'إ':
                case 'آ':
                case 'ٱ':
                    sb.append('ا');
                    break;
                case 'ى':
                    sb.append('ي');
                    break;
                case 'ة':
                    sb.append('ه');
                    break;
                default:
                    sb.append(Character.toLowerCase(c));
            }
        }
        return sb.toString();
    }
}
